#ifndef CAPTEURLIGNE_H__
#define CAPTEURLIGNE_H__
class CapteurLigne
{

public:
	int suiveur();
private:


};


#endif CAPTEURLIGNE_H__
