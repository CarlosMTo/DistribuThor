#ifndef CAPTEURSON_H__
#define CAPTEURSON_H__

class CapteurSon
{

public:
	bool ecouter(bool Etat);
private:
	bool m_son;

};


#endif //CAPTEURSON_H__
