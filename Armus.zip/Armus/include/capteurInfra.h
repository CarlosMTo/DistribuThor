#ifndef CAPTEURINFRA_H__
#define CAPTEURINFRA_H__
class CapteurInfra
{

public:
	float CalculDeDistance(float fTensionDistance);
	float voltage(int EntreeAnalogique);
	float DistanceCapteurChoisi(int numCapteur);
	int Capter(int ir1, int ir2, int ir0);

private:


};


#endif //CAPTEURINFRA_H__
