// Include Files

#include <libarmus.h>
#include "capteurSon.h"
#include "deplacement.h"
#include "capteurCouleur.h"
#include "capteurInfra.h"
#include "capteurLigne.h"

extern int adjd_dev;

// Global Functions
int sec = 0;
bool init = false;


int main()
{
	char NotreZone = 0;
	char ObjetPris = 0;
	CapteurSon cptson;
	cptson.m_son = false;
	Deplacement dep(59);
	CapteurCouleur coul;
	CapteurInfra capInf;
	float ir1 = 80.0, ir2 = 80.0, ir0 = 80.0;
	int ir;
	float irCompare1, irCompare2, irCompare0;

	//initialisation du capteur
	ERROR_CHECK(coul.color_Init(adjd_dev));

	coul.cap_SetValue(CAP_RED, 15);
	coul.cap_SetValue(CAP_GREEN, 15);
	coul.cap_SetValue(CAP_BLUE, 15);
	coul.cap_SetValue(CAP_CLEAR, 15);

	coul.integrationTime_SetValue(INTEGRATION_RED, 4095);
	coul.integrationTime_SetValue(INTEGRATION_GREEN, 4095);
	coul.integrationTime_SetValue(INTEGRATION_BLUE, 4095);
	coul.integrationTime_SetValue(INTEGRATION_CLEAR, 4095);
	SYSTEM_ResetTimer();



	ir = capInf.Capter(ir1, ir2, ir0);

	while(true)
	{
		cptson.ecouter();

		if(cptson.m_son == true)
		{
			init = true;
			//THREAD_MSleep(100);
			switch(coul.DetecZone())
			{
				case 1: //Rouge
					LCD_ClearAndPrint("CRI** CEST ROUGE");
					MOTOR_SetSpeed(MOTOR_LEFT,-50);
					MOTOR_SetSpeed(MOTOR_RIGHT,-50);
					THREAD_MSleep(1500);
					MOTOR_SetSpeed(MOTOR_LEFT,50);
					MOTOR_SetSpeed(MOTOR_RIGHT,-50);
					THREAD_MSleep(1500);
				break;

				case 2: //Bleu
					MOTOR_SetSpeed(MOTOR_LEFT,50);
					MOTOR_SetSpeed(MOTOR_RIGHT,54);
				break;
				case 3: //Vert
					MOTOR_SetSpeed(MOTOR_LEFT,50);
					MOTOR_SetSpeed(MOTOR_RIGHT,54);
				break;
				case 4: //Jaune
					MOTOR_SetSpeed(MOTOR_LEFT,50);
					MOTOR_SetSpeed(MOTOR_RIGHT,54);
				break;
				case 5: //Blanc
					MOTOR_SetSpeed(MOTOR_LEFT,50);
					MOTOR_SetSpeed(MOTOR_RIGHT,54);
				break;
				case 6: //Gris
					MOTOR_SetSpeed(MOTOR_LEFT,50);
					MOTOR_SetSpeed(MOTOR_RIGHT,54);
				break;
				case 7: //Rose
					MOTOR_SetSpeed(MOTOR_LEFT,50);
					MOTOR_SetSpeed(MOTOR_RIGHT,54);
				break;

				default:
					MOTOR_SetSpeed(MOTOR_LEFT,50);
					MOTOR_SetSpeed(MOTOR_RIGHT,54);
				break;
			}

			if(ObjetPris == 0)
			{
				switch(ir)
						{
						case 1:
							MOTOR_SetSpeed(MOTOR_LEFT,0);
							MOTOR_SetSpeed(MOTOR_RIGHT,0);
							ir1 = capInf.DistanceCapteurChoisi(ir);
							THREAD_MSleep(1000);
							irCompare1 = capInf.DistanceCapteurChoisi(ir);

							if (irCompare1 <= ir1 + 3 && irCompare1 >= ir1 - 3)
							{
								LCD_Printf("Objet 1 \n");
								SERVO_SetAngle(9, 115);
								THREAD_MSleep(500);
								ObjetPris = 1;
								MOTOR_SetSpeed(MOTOR_LEFT,-50);
								MOTOR_SetSpeed(MOTOR_RIGHT,50);
								THREAD_MSleep(1500);
							}
							break;
						case 2:
							ir2 = capInf.DistanceCapteurChoisi(ir);
							THREAD_MSleep(1000);
							irCompare2 = capInf.DistanceCapteurChoisi(ir);

							if (irCompare2 <= ir2 + 3 && irCompare2 >= ir2 - 3)
							{
								LCD_Printf("Objet 2 \n");
								MOTOR_SetSpeed(MOTOR_LEFT,-50);
								MOTOR_SetSpeed(MOTOR_RIGHT,50);
								THREAD_MSleep(750);
							}
							break;
						case 0:
							ir0 = capInf.DistanceCapteurChoisi(ir);
							THREAD_MSleep(1000);
							irCompare0 = capInf.DistanceCapteurChoisi(ir);

							if (irCompare0 <= ir0 + 3 && irCompare0 >= ir0 - 3)
							{
								LCD_Printf("Objet 3 \n");
								MOTOR_SetSpeed(MOTOR_LEFT,50);
								MOTOR_SetSpeed(MOTOR_RIGHT,-50);
								THREAD_MSleep(750);
							}
							break;
						default:
							break;
						}
			}
			else
			{
				if(coul.DetecZone() == NotreZone)
				{
					LCD_ClearAndPrint("Je suis chez moi !!");
					MOTOR_SetSpeed(MOTOR_LEFT,0);
					MOTOR_SetSpeed(MOTOR_RIGHT,0);
					ObjetPris = 0;
					SERVO_SetAngle(9, -30);
					THREAD_MSleep(500);
					MOTOR_SetSpeed(MOTOR_LEFT,-50);
					MOTOR_SetSpeed(MOTOR_RIGHT,-50);
					THREAD_MSleep(750);
					MOTOR_SetSpeed(MOTOR_LEFT,50);
					MOTOR_SetSpeed(MOTOR_RIGHT,-50);
					THREAD_MSleep(1500);
				}
			}

			ir = capInf.Capter(ir1, ir2, ir0);

			THREAD_MSleep(25);
		}

		if(sec >= 100)
		{
			sec = 0;
			MOTOR_SetSpeed(MOTOR_LEFT,0);
			MOTOR_SetSpeed(MOTOR_RIGHT,0);
			break;
		}

		if(init)
		{
			if(SYSTEM_ReadTimerMSeconds() > 999)
			{
				SYSTEM_ResetTimer();
				sec++;
			}
		}
		else
		{
			NotreZone = coul.DetecZone();
			SYSTEM_ResetTimer();
		}

		THREAD_MSleep(100);
	}
	LCD_ClearAndPrint("CEST FINIIIIII !!!!!");
	return 0;
}
