#ifndef CAPTEURS_H__
#define CAPTEUR_H__

class Capteur
{

public:
	float GetDistance(int capteur);
	int GetLineVoltage();

private:


};


#endif //CAPTEUR_H__
