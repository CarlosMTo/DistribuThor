#ifndef CAPTEURSON_H__
#define CAPTEURSON_H__

class CapteurSon
{

public:
	//bool ecouter(bool actif);
	void ecouter();
	bool m_son;
private:


};


#endif //CAPTEURSON_H__
