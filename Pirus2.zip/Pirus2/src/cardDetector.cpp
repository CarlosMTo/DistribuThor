#include <libarmus.h>
#include "cardDetector.h"


int CardDetector::getCouleur()
{

	//m_cap.DetecCarte();






	return 0;
			//m_cap.DetecCarte();
}

int CardDetector::getPoint()
{


	return getCouleur();
}
